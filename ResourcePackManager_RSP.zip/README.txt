RANK PACK
=========
Ky tu (Private Use Area)   Rank        File
  \uEC00                   OWNER       owner.png
  \uEC01                   MEMBERS     members.png
  \uEC02                   ADMIN       admin.png
  \uEC03                   TIKTOKER    tiktoker.png
  \uEC04                   KING        king.png
  \uEC05 ... \uECFF        con trong, dung cho rank moi

Anh rank cao 11 px (rong tuy y, nen trong suot). Neu doi chieu cao anh,
sua HEIGHT/ASCENT trong tools/build_font.py roi chay lai.

THEM RANK MOI
1. Bo anh PNG vao assets/minecraft/textures/font/ranks/ (vd helper.png)
2. Mo tools/ranks.txt, bo dau # o dong tuong ung hoac them dong moi, vd:  EC05 helper
3. Chay:  python3 tools/build_font.py

DUNG VOI LUCKPERMS
Prefix phai chua KY TU THAT, khong phai chu \uEC00. Copy lenh trong lp_prefix.txt
(mo bang Notepad), dan vao game hoac web editor. Dat &f truoc ky tu va 1 dau cach sau.
