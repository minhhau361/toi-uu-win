#!/usr/bin/env python3
"""Tao lai assets/minecraft/font/default.json tu tools/ranks.txt.

ranks.txt: moi dong  <ma hex> <ten file png khong co .png>
Dat anh vao assets/minecraft/textures/font/ranks/<ten>.png

HEIGHT = chieu cao hien thi (px), nen bang chieu cao anh (hien tai 11).
ASCENT = khoang cach tu dinh anh den duong chu (<= HEIGHT). Tang/giam de nang/ha icon.
Chay:  python3 tools/build_font.py
"""
import json, os
HEIGHT = 11
ASCENT = 9
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
providers = []
with open(os.path.join(root, "tools", "ranks.txt"), encoding="utf-8") as f:
    for line in f:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        code, name = line.split()
        providers.append({
            "type": "bitmap",
            "file": f"minecraft:font/ranks/{name}.png",
            "ascent": ASCENT, "height": HEIGHT,
            "chars": [chr(int(code, 16))],
        })
out = os.path.join(root, "assets", "minecraft", "font", "default.json")
with open(out, "w", encoding="utf-8") as f:
    json.dump({"providers": providers}, f, indent=2)
print(f"Wrote {len(providers)} provider(s) to {out}")
